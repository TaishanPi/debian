/******************************************************************************
 *
 * Copyright 2019, Fuzhou Rockchip Electronics Co.Ltd . All rights reserved.
 * No part of this work may be reproduced, modified, distributed, transmitted,
 * transcribed, or translated into any language or computer format, in any form
 * or by any means without written permission of:
 * Fuzhou Rockchip Electronics Co.Ltd .
 *
 *
 *****************************************************************************/
#ifndef __RK_AIQ_TYPES_ATMO_ALGO_H__
#define __RK_AIQ_TYPES_ATMO_ALGO_H__

#include "algos/atmo/rk_aiq_types_atmo_stat_v200.h"


#endif
